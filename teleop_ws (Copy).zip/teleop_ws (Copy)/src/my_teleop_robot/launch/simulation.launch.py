"""
Main Launch File
=================
Launches everything:
  1. Gazebo Harmonic with the world
  2. Spawn the robot
  3. ros_gz_bridge for topic bridging
  4. robot_state_publisher for TF
  5. teleop_node (in separate terminal)
  6. status_node (in separate terminal)
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    IncludeLaunchDescription,
    TimerAction,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
import xacro


def generate_launch_description():
    # Package paths
    pkg_dir = get_package_share_directory('my_teleop_robot')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    # Process xacro → URDF string
    xacro_file = os.path.join(pkg_dir, 'urdf', 'robot.urdf.xacro')
    robot_description = xacro.process_file(xacro_file).toxml()

    # World file
    world_file = os.path.join(pkg_dir, 'worlds', 'simple_city.sdf')

    # Bridge config
    bridge_config = os.path.join(pkg_dir, 'config', 'bridge.yaml')

    # ────────────────── GAZEBO ──────────────────
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={
            'gz_args': f'-r {world_file}',
            'on_exit_shutdown': 'true',
        }.items(),
    )

    # ────────────────── SPAWN ROBOT ──────────────────
    spawn_robot = TimerAction(
        period=3.0,  # Wait for Gazebo to start
        actions=[
            Node(
                package='ros_gz_sim',
                executable='create',
                arguments=[
                    '-name', 'teleop_robot',
                    '-string', robot_description,
                    '-x', '-5.0',
                    '-y', '0.0',
                    '-z', '0.1',
                    '-Y', '0.0',
                ],
                output='screen',
            )
        ],
    )

    # ────────────────── ROBOT STATE PUBLISHER ──────────────────
    robot_state_pub = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_description}],
        output='screen',
    )

    # ────────────────── ROS-GZ BRIDGE ──────────────────
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['--ros-args', '-p', f'config_file:={bridge_config}'],
        output='screen',
    )

    # ────────────────── STATUS NODE ──────────────────
    status_node = Node(
        package='my_teleop_robot',
        executable='status_node',
        name='status_node',
        output='screen',
        prefix='xterm -title "Robot Status" -fa Monospace -fs 11 -e',
    )

    # ────────────────── TELEOP NODE ──────────────────
    teleop_node = Node(
        package='my_teleop_robot',
        executable='teleop_node',
        name='teleop_node',
        output='screen',
        prefix='xterm -title "Teleop Control" -fa Monospace -fs 11 -e',
    )

    return LaunchDescription([
        gazebo,
        spawn_robot,
        robot_state_pub,
        bridge,
        TimerAction(period=5.0, actions=[status_node]),
        TimerAction(period=5.0, actions=[teleop_node]),
    ])
