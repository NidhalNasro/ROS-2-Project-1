import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'my_teleop_robot'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        # Package index
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        # Package manifest
        ('share/' + package_name, ['package.xml']),
        # Launch files
        (os.path.join('share', package_name, 'launch'),
         glob('launch/*.py')),
        # URDF files
        (os.path.join('share', package_name, 'urdf'),
         glob('urdf/*')),
        # World files
        (os.path.join('share', package_name, 'worlds'),
         glob('worlds/*')),
        # Config files
        (os.path.join('share', package_name, 'config'),
         glob('config/*')),
        # RViz config
        (os.path.join('share', package_name, 'rviz'),
         glob('rviz/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='you',
    maintainer_email='you@example.com',
    description='Simple ROS 2 teleoperation robot in Gazebo',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'teleop_node = my_teleop_robot.teleop_node:main',
            'status_node = my_teleop_robot.status_node:main',
        ],
    },
)
