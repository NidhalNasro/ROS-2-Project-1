#!/usr/bin/env python3
"""
Keyboard Teleoperation Node
============================
Controls the robot like a basic car game:
  W / ↑  : Drive forward
  S / ↓  : Drive backward
  A / ←  : Turn left
  D / →  : Turn right
  SPACE  : Brake (instant stop)
  Q      : Quit

Publishes: geometry_msgs/Twist on /cmd_vel
"""

import sys
import termios
import tty
import select

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


# Key bindings
FORWARD_KEYS = {'w', 'W', '\x1b[A'}   # w and Up arrow
BACKWARD_KEYS = {'s', 'S', '\x1b[B'}  # s and Down arrow
LEFT_KEYS = {'a', 'A', '\x1b[D'}      # a and Left arrow
RIGHT_KEYS = {'d', 'D', '\x1b[C'}     # d and Right arrow
BRAKE_KEYS = {' '}                      # spacebar
QUIT_KEYS = {'q', 'Q', '\x03'}        # q or Ctrl+C


class TeleopNode(Node):
    """Keyboard teleoperation node for the robot."""

    def __init__(self):
        super().__init__('teleop_node')

        # Parameters
        self.declare_parameter('max_linear_speed', 2.0)
        self.declare_parameter('max_angular_speed', 1.5)
        self.declare_parameter('linear_step', 0.1)
        self.declare_parameter('angular_step', 0.1)
        self.declare_parameter('publish_rate', 20.0)

        self.max_linear = self.get_parameter('max_linear_speed').value
        self.max_angular = self.get_parameter('max_angular_speed').value
        self.linear_step = self.get_parameter('linear_step').value
        self.angular_step = self.get_parameter('angular_step').value
        rate = self.get_parameter('publish_rate').value

        # Publisher
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # Current velocity state
        self.linear_vel = 0.0
        self.angular_vel = 0.0

        # Timer to publish at fixed rate
        self.timer = self.create_timer(1.0 / rate, self.publish_velocity)

        # Save terminal settings
        self.settings = termios.tcgetattr(sys.stdin)

        self.print_instructions()
        self.get_logger().info('Teleop node started — use keyboard to drive!')

    def print_instructions(self):
        """Print control instructions to terminal."""
        msg = """
╔══════════════════════════════════════════════╗
║        🚗  ROBOT TELEOP CONTROLLER  🚗       ║
╠══════════════════════════════════════════════╣
║                                              ║
║         W / ↑   : Accelerate forward         ║
║         S / ↓   : Accelerate backward        ║
║         A / ←   : Turn left                  ║
║         D / →   : Turn right                 ║
║         SPACE   : Brake (stop)               ║
║         Q       : Quit                       ║
║                                              ║
║  Speed builds up gradually, like a car!      ║
╚══════════════════════════════════════════════╝
"""
        print(msg)

    def get_key(self):
        """Read a single keypress from terminal (non-blocking)."""
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.05)
        if rlist:
            key = sys.stdin.read(1)
            # Handle arrow keys (escape sequences)
            if key == '\x1b':
                key += sys.stdin.read(2)
        else:
            key = ''
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def publish_velocity(self):
        """Read key and publish velocity command."""
        key = self.get_key()

        if key in QUIT_KEYS:
            # Stop the robot before quitting
            self.stop_robot()
            self.get_logger().info('Shutting down teleop node...')
            raise SystemExit

        if key in FORWARD_KEYS:
            self.linear_vel = min(
                self.linear_vel + self.linear_step, self.max_linear
            )
        elif key in BACKWARD_KEYS:
            self.linear_vel = max(
                self.linear_vel - self.linear_step, -self.max_linear
            )
        elif key in LEFT_KEYS:
            self.angular_vel = min(
                self.angular_vel + self.angular_step, self.max_angular
            )
        elif key in RIGHT_KEYS:
            self.angular_vel = max(
                self.angular_vel - self.angular_step, -self.max_angular
            )
        elif key in BRAKE_KEYS:
            self.linear_vel = 0.0
            self.angular_vel = 0.0
        else:
            # Gradual deceleration when no key pressed (natural feel)
            self.linear_vel *= 0.95
            self.angular_vel *= 0.90

            # Snap to zero if very small
            if abs(self.linear_vel) < 0.01:
                self.linear_vel = 0.0
            if abs(self.angular_vel) < 0.01:
                self.angular_vel = 0.0

        # Create and publish Twist message
        twist = Twist()
        twist.linear.x = self.linear_vel
        twist.angular.z = self.angular_vel
        self.pub.publish(twist)

        # Show speed bar in terminal
        self.display_speed()

    def display_speed(self):
        """Show a simple speed indicator in the terminal."""
        bar_len = 20
        # Linear speed bar
        lin_pct = self.linear_vel / self.max_linear
        lin_filled = int(abs(lin_pct) * bar_len)
        lin_dir = '▶' if self.linear_vel >= 0 else '◀'
        lin_bar = '█' * lin_filled + '░' * (bar_len - lin_filled)

        # Angular bar
        ang_pct = self.angular_vel / self.max_angular
        ang_filled = int(abs(ang_pct) * bar_len)
        ang_dir = '↺' if self.angular_vel >= 0 else '↻'
        ang_bar = '█' * ang_filled + '░' * (bar_len - ang_filled)

        status = (
            f'\r  Speed {lin_dir}: [{lin_bar}] {self.linear_vel:+.2f} m/s  |  '
            f'Turn {ang_dir}: [{ang_bar}] {self.angular_vel:+.2f} rad/s   '
        )
        sys.stdout.write(status)
        sys.stdout.flush()

    def stop_robot(self):
        """Publish zero velocity to stop the robot."""
        twist = Twist()
        self.pub.publish(twist)

    def destroy_node(self):
        """Clean up terminal settings on shutdown."""
        self.stop_robot()
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
