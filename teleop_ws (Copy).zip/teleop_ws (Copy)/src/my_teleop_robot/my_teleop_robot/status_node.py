#!/usr/bin/env python3
"""
Robot Status Node
==================
Subscribes to /cmd_vel and /odom, displays:
  - Current linear & angular velocity commands
  - Actual odometry-based speed
  - Movement direction (Forward/Backward/Left/Right/Stopped)
  - Position (x, y) from odometry
  - Total distance traveled

Publishes: nothing (display-only node)
"""

import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry


class StatusNode(Node):
    """Displays robot status information in the terminal."""

    def __init__(self):
        super().__init__('status_node')

        # Subscribers
        self.cmd_sub = self.create_subscription(
            Twist, '/cmd_vel', self.cmd_vel_callback, 10
        )
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10
        )

        # State variables
        self.cmd_linear = 0.0
        self.cmd_angular = 0.0
        self.odom_linear = 0.0
        self.odom_angular = 0.0
        self.pos_x = 0.0
        self.pos_y = 0.0
        self.yaw = 0.0
        self.total_distance = 0.0
        self.last_x = None
        self.last_y = None

        # Display timer at 5 Hz (not too fast, easy to read)
        self.timer = self.create_timer(0.2, self.display_status)

        self.get_logger().info('Status node started — monitoring robot state...')

    def cmd_vel_callback(self, msg: Twist):
        """Store latest commanded velocity."""
        self.cmd_linear = msg.linear.x
        self.cmd_angular = msg.angular.z

    def odom_callback(self, msg: Odometry):
        """Store latest odometry data and accumulate distance."""
        self.odom_linear = msg.twist.twist.linear.x
        self.odom_angular = msg.twist.twist.angular.z

        self.pos_x = msg.pose.pose.position.x
        self.pos_y = msg.pose.pose.position.y

        # Extract yaw from quaternion
        q = msg.pose.pose.orientation
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        self.yaw = math.atan2(siny_cosp, cosy_cosp)

        # Accumulate total distance traveled
        if self.last_x is not None:
            dx = self.pos_x - self.last_x
            dy = self.pos_y - self.last_y
            self.total_distance += math.sqrt(dx * dx + dy * dy)
        self.last_x = self.pos_x
        self.last_y = self.pos_y

    def get_direction(self) -> str:
        """Determine movement direction from commanded velocity."""
        lin = self.cmd_linear
        ang = self.cmd_angular

        if abs(lin) < 0.01 and abs(ang) < 0.01:
            return '⏹  STOPPED'
        
        directions = []
        if lin > 0.05:
            directions.append('⬆ Forward')
        elif lin < -0.05:
            directions.append('⬇ Backward')
        
        if ang > 0.05:
            directions.append('⬅ Left')
        elif ang < -0.05:
            directions.append('➡ Right')

        return ' + '.join(directions) if directions else '⏹  STOPPED'

    def get_speed_bar(self, value: float, max_val: float, width: int = 15) -> str:
        """Create a simple ASCII progress bar."""
        pct = min(abs(value) / max_val, 1.0) if max_val > 0 else 0
        filled = int(pct * width)
        return '█' * filled + '░' * (width - filled)

    def display_status(self):
        """Print a formatted status display."""
        yaw_deg = math.degrees(self.yaw)

        # Clear screen and print status box
        status = f"""
\033[2J\033[H
╔════════════════════════════════════════════════════╗
║            🤖  ROBOT STATUS MONITOR  🤖            ║
╠════════════════════════════════════════════════════╣
║                                                    ║
║  COMMAND VELOCITY:                                 ║
║    Linear:  {self.cmd_linear:+7.3f} m/s  [{self.get_speed_bar(self.cmd_linear, 2.0)}] ║
║    Angular: {self.cmd_angular:+7.3f} rad/s [{self.get_speed_bar(self.cmd_angular, 1.5)}] ║
║                                                    ║
║  ACTUAL VELOCITY (Odometry):                       ║
║    Linear:  {self.odom_linear:+7.3f} m/s                       ║
║    Angular: {self.odom_angular:+7.3f} rad/s                     ║
║                                                    ║
║  DIRECTION: {self.get_direction():<38s}║
║                                                    ║
║  POSITION:                                         ║
║    X: {self.pos_x:+8.3f} m    Y: {self.pos_y:+8.3f} m               ║
║    Heading: {yaw_deg:+7.1f}°                              ║
║                                                    ║
║  DISTANCE TRAVELED: {self.total_distance:8.2f} m                   ║
║                                                    ║
╚════════════════════════════════════════════════════╝
"""
        print(status, end='')


def main(args=None):
    rclpy.init(args=args)
    node = StatusNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
